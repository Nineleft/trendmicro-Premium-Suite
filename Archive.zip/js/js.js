var app = new Vue({
  el: '#app',
  data: {
    showProducts: false,
    showWindows: false,
    showApple: false,
    showMobile: false,
    showChrome: false,
  }
})
